"""Persist the assistant's completed five-case textual review, after inspection."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
checks_raw = (OUT / "independent_checks.json").read_bytes()
checks = json.loads(checks_raw)["checks"]
observations = {
    "0000040554-14-000023": {
        "start_cue": "Item 1A. Risk Factors -> The following discussion of risk factors contains forward-looking statements",
        "end_cue": "Supplier/commodity exposure paragraph ending liability and reputational harm, followed by Item 1B. Unresolved Staff Comments / Not applicable",
        "content_observations": [
            "The initial contents entry points to Item 1A on printed page 15 and Item 1B on printed page 21. The selected text starts after the second, substantive Item 1A heading following the end of Business, not the initial contents entry.",
            "Read all 40 matched original source text events. The opening interpretive cautions, global economic/political risks, legal/regulatory and nonbank SIFI risks, transactions, pensions, funding, counterparty/credit-rating risks, cybersecurity, operations, intellectual property, and final supplier/commodity risk are present in original order.",
            "References to Business, MD&A, Legal Proceedings and financial-statement notes remain inside the risk discussion. They provide additional information; this substantive Item 1A does not replace itself with a separate exhibit or page-only pointer.",
            "The final supplier paragraph is complete through its last word. Original HTML has a terminal full stop, which the existing extraction strips. Item 1B and the subsequent Properties section are excluded. Internal printed-page labels (15) through (20) remain in the extracted text.",
        ],
        "normalization_limitations": ["Retained internal printed-page labels", "One terminal full stop removed by the existing text-strip behavior"],
    },
    "0000050863-14-000020": {
        "start_cue": "ITEM 1A. RISK FACTORS -> Changes in product demand may harm our financial results and are hard to predict",
        "end_cue": "Controls paragraph ending policies or procedures, then page 23 / Table of Contents, then ITEM 1B. UNRESOLVED STAFF COMMENTS / Not applicable",
        "content_observations": [
            "The index points to Item 1A on printed page 17 and Item 1B on page 24. The selected text is the second Item 1A occurrence after the executive biography material and printed-page-16 furniture.",
            "Read all 189 matched source events, including all bullet lists. Demand, competition, product mix, global operations, production/resources, defects, cyber/privacy, intellectual property, litigation, distribution/government sales, investments/accounting/tax, restructuring/transactions, environmental and climate issues, workforce, interest and controls text remain in the same order.",
            "The environmental discussion continues across the page-22/Table-of-Contents furniture into conflict-mineral disclosure; that continuation is retained before the climate, workforce and controls discussions.",
            "Internal Note 26 and Critical Accounting Estimates references remain as source text; no substitute exhibit or page-pointer-only Item 1A occurs. The complete controls paragraph and page-23 furniture are followed by the actual Item 1B and Properties headings, both excluded from the extraction.",
        ],
        "normalization_limitations": ["Internal page numbers and repeated Table of Contents navigation text are retained, including trailing page-23 furniture"],
    },
    "0000050863-15-000015": {
        "start_cue": "ITEM 1A. RISK FACTORS -> The following risks could materially and adversely affect our business",
        "end_cue": "Controls paragraph ending market price of our stock could decline, then page 25 / Table of Contents, then ITEM 1B. UNRESOLVED STAFF COMMENTS / Not applicable",
        "content_observations": [
            "The front index points to Item 1A on printed page 18 and Item 1B on page 26. The selected second Item 1A heading follows executive biographies and the printed-page-17 furniture, so the index entry was not treated as substantive text.",
            "Read all 202 matched original source events. The opening broad caution and all demand/competition/mix, global/currency/catastrophic, manufacturing/supply/defect/environment, intellectual-property/litigation/workforce, cyber/privacy, strategic-transaction/sales, accounting/tax, repurchase, restructuring and controls discussions are retained.",
            "Supply-chain discussion continues after page-20/Table-of-Contents furniture into third-party manufacturing and sourcing requirements. The continuation is preserved; bullet lists and inline percentages are present.",
            "The text's references to MD&A, Note 25 and Note 13 remain as internal references, with no exhibit substituted for Item 1A. The final controls paragraph, page-25 furniture and transition to true Item 1B establish the ending; Item 1B and Properties are excluded.",
        ],
        "normalization_limitations": ["Internal page numbers and repeated Table of Contents navigation text are retained, including trailing page-25 furniture"],
    },
    "0000050863-16-000105": {
        "start_cue": "ITEM 1A. RISK FACTORS -> The following risks could materially and adversely affect our business",
        "end_cue": "Controls paragraph ending market price of our stock could decline, then page 27 / Table of Contents, then ITEM 1B. UNRESOLVED STAFF COMMENTS / Not applicable",
        "content_observations": [
            "The front index points to Item 1A on printed page 20 and Item 1B on page 28. The selected second Item 1A occurrence follows the CEO biography and printed-page-19 furniture.",
            "Read all 208 matched original source events. The opening caution, demand and competition, global and currency exposure, catastrophe, manufacturing/supply/defects/environment, intellectual property/litigation, workforce, cyber/privacy, transactions/distribution/government, accounting/tax, repurchase, restructuring and controls discussions are present in source order.",
            "The supply-chain paragraph before page-22 furniture continues with third-party manufacture/assembly/testing and supplier-conduct restrictions afterwards. Both continuation paragraphs are retained. The extracted text also preserves the discussion of defects in third-party components and products.",
            "Note 25, Note 13, MD&A and accounting references are internal discussion references; no missing incorporated exhibit or page-only substitution was observed. The full controls paragraph and trailing page-27 furniture end immediately before substantive Item 1B and Properties.",
        ],
        "normalization_limitations": ["Internal page numbers and repeated Table of Contents navigation text are retained, including trailing page-27 furniture"],
    },
    "0000050863-17-000012": {
        "start_cue": "ITEM 1A.RISK FACTORS -> The following risks could materially and adversely affect our business",
        "end_cue": "Controls paragraph ending market price of our stock could decline, followed by ITEM 1B. UNRESOLVED STAFF COMMENTS / Not applicable",
        "content_observations": [
            "The index points to Item 1A on printed page 15 and Item 1B on page 24. The selected second Item 1A occurrence follows the Robert Swan/eBay director biography, not the front index.",
            "Read all 227 matched original source events. The opening caution and demand/mix, competition, global/currency/catastrophe, manufacturing and supplier, product-defect, environment, intellectual-property/litigation, workforce, cyber/privacy, transactions/sales, accounting/tax, repurchase, restructuring and controls material are retained.",
            "The competitive discussion continues after page-15 furniture into R&D; environmental discussion continues after page-18 furniture; final controls discussion follows page-23 furniture. Those continuations, expanded product-injury risks, distributor paragraphs and the restructuring bullet list are preserved.",
            "MD&A and Notes 20, 2 and 7 are additional internal references rather than an external replacement for the section. The last controls paragraph is complete through its last word; its final period is stripped by the existing normalizer. The immediately following Item 1B and Properties are excluded.",
        ],
        "normalization_limitations": ["Internal page numbers and repeated Table of Contents navigation text are retained", "One terminal full stop removed by the existing text-strip behavior"],
    },
}
timestamp = datetime.now(timezone.utc).isoformat()
reviews = []
for check in checks:
    a = check["accession"]
    for source_key in ("source", "header"):
        source = check[source_key]
        stem = ROOT / "data/raw/sec_cache" / sha256(source["url"].encode()).hexdigest()
        assert sha256(stem.with_suffix(".bin").read_bytes()).hexdigest() == source["sha256"]
        assert sha256(stem.with_suffix(".json").read_bytes()).hexdigest() == source["metadata_sha256"]
    assert check["complete_extracted_text_matches_one_contiguous_independent_visible_source_span"]
    assert not check["hidden_text_events_in_span"] and not check["images_in_span"]
    obs = observations[a]
    reviews.append({
        "accession": a, "evidence_id": check["evidence_id"],
        "reviewer": "ChatGPT (delegated GE/Intel original-source textual review)",
        "reviewer_type": "assistant", "reviewed_at": timestamp,
        "boundary_verdict": "pass", "timing_verdict": "pending",
        "notes": " ".join(obs["content_observations"]) + " Complete extracted span independently matches one contiguous visible-source text sequence after ignoring whitespace/zero-width spaces; no hidden text or image elements were found inside that span. This is assistant textual source inspection, not human review or a complete visual-layout review. Timing is reserved for the separate parent review.",
        "source_url": check["source"]["url"], "source_sha256": check["source"]["sha256"],
        "risk_source_url": check["source"]["url"], "risk_source_sha256": check["source"]["sha256"],
        "header_url": check["header"]["url"], "header_sha256": check["header"]["sha256"],
        "risk_text_sha256": check["risk_text_sha256"],
        "original_source_bytes_reread": True,
        "source_cache_metadata_rechecked_after_review": True,
        "source_review_method": "Read independently parsed original HTML text events and adjacent headings; full span correspondence uses Python HTMLParser without production extraction/normalization helpers",
        "comparison_canonicalization": "Remove whitespace and zero-width spaces only; no word, numeric or punctuation substitution",
        "matched_original_text_events": check["matched_event_count"],
        "source_span_canonical_start": check["canonical_start"],
        "source_span_canonical_end": check["canonical_end"],
        "item_1a_heading_occurrences": check["item_1a_heading_occurrences"],
        "item_1b_heading_occurrences": check["item_1b_heading_occurrences"],
        "hidden_source_text_events_within_span": 0,
        "image_elements_within_span": 0,
        "substantive_boundary_defect_found": False,
        "visual_layout_review_completed": False,
        "human_review_created": False,
        **obs,
    })
result = {
    "schema_version": 1,
    "scope": "Five previously unreviewed reference-control filings in the 73-filing desk",
    "review_completed_at": timestamp,
    "assistant_agent": "/root/review_reference_ge_intel",
    "independent_checks_file": "independent_checks.json",
    "independent_checks_sha256": sha256(checks_raw).hexdigest(),
    "packet_sha256": sha256((ROOT / "reports/filing_review/packet.json").read_bytes()).hexdigest(),
    "boundary_passes": 5, "boundary_failures": 0, "boundary_pending": 0,
    "timing_review_delegated_to_parent": True,
    "human_reviews_created": 0, "market_data_read": False, "final_period_opened": False,
    "reviews": reviews,
}
output = OUT / "review_findings.json"
with output.open("x") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(json.dumps({"output": str(output), "sha256": sha256(output.read_bytes()).hexdigest(), "reviewed_at": timestamp, "boundary_passes": 5, "timing_review": "pending parent", "human_reviews_created": 0}, indent=2))
