"""Independent source text event inspection; no repository extractor imports.

This helper establishes byte and complete textual-span correspondences. It does
not itself assign review verdicts or assert visual-layout completeness.
"""
from datetime import datetime, timezone
from difflib import unified_diff
from hashlib import sha256
from html.parser import HTMLParser
import json
from pathlib import Path
import re

import pyarrow.parquet as pq

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
ACCESSIONS = [
    "0000040554-14-000023", "0000050863-14-000020", "0000050863-15-000015",
    "0000050863-16-000105", "0000050863-17-000012",
]
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}


def canon(text):
    return re.sub(r"\s+", "", text).replace("\u200b", "")


class OriginalTextEvents(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.events = []
        self.images = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        style = re.sub(r"\s+", "", attrs.get("style", "").lower())
        entry = {"tag": tag, "attrs": attrs, "hidden": tag in {"script", "style", "noscript"} or tag.endswith(":hidden") or "display:none" in style or "visibility:hidden" in style}
        if tag == "img":
            self.images.append({"text_event_index": len(self.events), "attrs": attrs})
        if tag not in VOID:
            self.stack.append(entry)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i]["tag"] == tag:
                self.stack = self.stack[:i]
                break

    def handle_data(self, data):
        if not data.strip():
            return
        self.events.append({
            "text": data, "source_line_column": self.getpos(),
            "hidden": any(x["hidden"] for x in self.stack),
            "ancestor_tags": [x["tag"] for x in self.stack],
            "styles": [x["attrs"]["style"] for x in self.stack if x["attrs"].get("style")],
            "links": [x["attrs"]["href"] for x in self.stack if x["attrs"].get("href")],
        })


def cached(url, wanted):
    stem = ROOT / "data/raw/sec_cache" / sha256(url.encode()).hexdigest()
    raw = stem.with_suffix(".bin").read_bytes()
    meta_raw = stem.with_suffix(".json").read_bytes()
    meta = json.loads(meta_raw)
    actual = sha256(raw).hexdigest()
    assert actual == wanted == meta["sha256"]
    assert meta["url"] == url and meta["bytes"] == len(raw) and meta["status"] == 200
    return raw, {"url": url, "sha256": actual, "bytes": len(raw), "metadata_sha256": sha256(meta_raw).hexdigest(), "fetched_at": meta["fetched_at"], "representation": meta.get("body_representation")}


packet = json.loads((ROOT / "reports/filing_review/packet.json").read_text())
packet_rows = {f["accession"]: f for f in packet["filings"]}
evidence = {f["accession"]: f for f in pq.read_table(ROOT / "outputs/audit-pilot-resolved/filing_evidence.parquet").to_pylist()}
filing_rows = {f["accessionNumber"]: f for f in pq.read_table(ROOT / "data/processed/pilot-resolved/filings.parquet").to_pylist()}
checks = []
for accession in ACCESSIONS:
    f, e, stored = packet_rows[accession], evidence[accession], filing_rows[accession]
    assert e["source_url"] == e["risk_source_url"] == f["source_url"] == f["risk_source_url"] == stored["source_url"]
    raw, src = cached(f["source_url"], e["download_sha256"])
    header, hdr = cached(f["header_url"], e["header_sha256"])
    assert stored["download_sha256"] == src["sha256"] == e["risk_source_sha256"]
    assert stored["risk_text"] == f["risk_text"] and sha256(f["risk_text"].encode()).hexdigest() == e["risk_text_sha256"]
    parser = OriginalTextEvents()
    parser.feed(raw.decode("ascii"))
    parser.close()
    visible = [(i, event) for i, event in enumerate(parser.events) if not event["hidden"]]
    pieces = [canon(ev["text"]) for _, ev in visible]
    original = "".join(pieces)
    risk = canon(f["risk_text"])
    positions = [m.start() for m in re.finditer(re.escape(risk), original)]
    assert len(positions) == 1, (accession, len(positions))
    start, end = positions[0], positions[0] + len(risk)
    matching_events, pos = [], 0
    for (i, event), piece in zip(visible, pieces):
        ev_end = pos + len(piece)
        if ev_end > start and pos < end:
            matching_events.append({"event_index": i, "canonical_start": pos, "canonical_end": ev_end, **event})
        pos = ev_end
    first_event, last_event = matching_events[0]["event_index"], matching_events[-1]["event_index"]
    context = parser.events[max(0, first_event - 7):last_event + 8]
    hidden_in_span = [ev for ev in parser.events[first_event:last_event+1] if ev["hidden"]]
    images_in_span = [im for im in parser.images if first_event <= im["text_event_index"] <= last_event]
    headings = []
    for match in re.finditer(r"item1a[.\-:–—]*riskfactors", original, flags=re.I):
        headings.append({"canonical_offset": match.start(), "context": original[max(0,match.start()-80):match.end()+180]})
    end_headings = []
    for match in re.finditer(r"item1b[.\-:–—]*unresolvedstaffcomments", original, flags=re.I):
        end_headings.append({"canonical_offset": match.start(), "context": original[max(0,match.start()-80):match.end()+100]})
    inspection = {
        "accession": accession, "evidence_id": f["evidence_id"], "name": f["name"],
        "source": src, "header": hdr, "risk_text_sha256": e["risk_text_sha256"],
        "complete_extracted_text_matches_one_contiguous_independent_visible_source_span": True,
        "comparison_ignores_whitespace_and_zero_width_spaces_only": True,
        "canonical_start": start, "canonical_end": end, "canonical_length": len(risk),
        "source_text_event_count": len(parser.events), "matched_event_count": len(matching_events),
        "first_event_index": first_event, "last_event_index": last_event,
        "immediate_before_span": original[max(0, start-300):start],
        "immediate_after_span": original[end:end+300],
        "item_1a_heading_occurrences": headings, "item_1b_heading_occurrences": end_headings,
        "hidden_text_events_in_span": hidden_in_span, "images_in_span": images_in_span,
        "header_original": header.decode("ascii"),
        "full_visual_layout_review_performed": False,
    }
    (OUT / f"{accession}.source-context.json").write_text(json.dumps({"inspection": inspection, "events": context}, ensure_ascii=False, indent=2)+"\n")
    (OUT / f"{accession}.risk.txt").write_text(f["risk_text"]+"\n")
    # Text event reading view is independently parsed from original HTML; the
    # packet text file above is only a comparison/diff convenience.
    (OUT / f"{accession}.original-events.txt").write_text("\n".join(f"{ev['event_index']}: {ev['text']}" for ev in matching_events)+"\n")
    checks.append(inspection)
for previous, current in zip(ACCESSIONS[1:], ACCESSIONS[2:]):
    before = packet_rows[previous]["risk_text"].splitlines(keepends=True)
    after = packet_rows[current]["risk_text"].splitlines(keepends=True)
    (OUT / f"{previous}__{current}.diff.txt").write_text("".join(unified_diff(before, after, fromfile=previous, tofile=current)))
result = {"generated_at": datetime.now(timezone.utc).isoformat(), "method": "Python standard-library HTMLParser data events, without production extraction/normalization helpers", "checks": checks, "reviews_created": 0}
(OUT / "independent_checks.json").write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n")
print(json.dumps({"filings": len(checks), "full_span_match": all(c["complete_extracted_text_matches_one_contiguous_independent_visible_source_span"] for c in checks), "output": str(OUT)}, indent=2))
