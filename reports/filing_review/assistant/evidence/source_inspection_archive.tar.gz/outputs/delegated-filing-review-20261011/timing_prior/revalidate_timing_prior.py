"""Independent, offline SGML/session and prior-review check for a frozen SEC packet.

No project timing, extraction, review, or audit helper is called. Calendar dates
come from the locked exchange_calendars dependency; this independently checks the
project's event arithmetic, not the external accuracy of that calendar provider.
Only public SEC inputs are opened. This script records assistant investigation,
never human judgments, historical security links, or source approvals.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import date, datetime, timezone
from hashlib import sha256
import importlib.metadata
import io
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo

import exchange_calendars
import pyarrow.parquet as pq


FINGERPRINT_FIELDS = (
    "accession", "source_url", "header_url", "download_sha256", "header_sha256",
    "extraction_version", "risk_text_sha256", "acceptance_timestamp", "api_timestamp",
    "reference_session", "label_end", "controls_through", "risk_source_url",
    "risk_source_sha256", "resolution_method", "resolution_rule_id", "resolution_index_url",
    "resolution_index_sha256", "extraction_start", "extraction_end", "normalizer_version",
)
SOURCE_FILES = {
    "filings": "data/processed/pilot-resolved/filings.parquet",
    "pairs": "data/processed/pilot-resolved/filing_pairs.parquet",
    "evidence": "outputs/audit-pilot-resolved/filing_evidence.parquet",
    "audit_summary": "outputs/audit-pilot-resolved/audit_summary.json",
    "selected_pairs": "reports/expanded_review_pairs.csv",
    "reference_template": "reports/reference_reviews.template.jsonl",
}
NY = ZoneInfo("America/New_York")
MAX_BYTES = 64 * 1024 * 1024


def digest(raw: bytes) -> str:
    return sha256(raw).hexdigest()


def unique_object(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def no_constant(value):
    raise ValueError(f"Nonfinite JSON constant: {value}")


def parse(raw: bytes):
    return json.loads(raw, object_pairs_hook=unique_object, parse_constant=no_constant)


def read(path: Path) -> bytes:
    with path.open("rb") as handle:
        raw = handle.read(MAX_BYTES + 1)
    if not raw or len(raw) > MAX_BYTES:
        raise ValueError(f"Empty or oversized input: {path.name}")
    return raw


def require(condition, message):
    if not condition:
        raise ValueError(message)


def binding(raw: bytes):
    return {"sha256": digest(raw), "bytes": len(raw)}


def aware(value: str) -> datetime:
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    require(result.tzinfo is not None and result.utcoffset() is not None, "Naive timestamp")
    return result


def development_day(value: str):
    day = date.fromisoformat(value)
    require(2010 <= day.year <= 2021, f"Outside development source envelope: {value}")
    return day


def cache_read(root: Path, url: str, expected: str, cache_bindings: dict):
    parsed = urlsplit(url)
    require(parsed.scheme == "https" and parsed.hostname in {"www.sec.gov", "data.sec.gov"}
            and parsed.username is None and parsed.password is None
            and parsed.port in {None, 443}, "Nonofficial SEC source URL")
    key = digest(url.encode())
    folder = root / "data/raw/sec_cache"
    body = read(folder / f"{key}.bin")
    metadata_raw = read(folder / f"{key}.json")
    metadata = parse(metadata_raw)
    require(metadata["url"] == url, "Cached source URL differs")
    require(digest(body) == expected == metadata["sha256"], "Original source hash differs")
    require(metadata.get("bytes") == len(body), "Cached source byte length differs")
    require(metadata.get("status") == 200, "Cached source lacks successful HTTP status")
    entry = {"url": url, "cache_key": key, **binding(body),
             "metadata_sha256": digest(metadata_raw),
             "recorded_fetched_at": metadata.get("fetched_at"),
             "recorded_body_representation": metadata.get("body_representation")}
    if url in cache_bindings:
        require(cache_bindings[url] == entry, "Source changed during investigation")
    cache_bindings[url] = entry
    return body


def header_field(raw: bytes, tag: str) -> tuple[str, int]:
    matches = list(re.finditer(rb"(?im)^\s*<" + re.escape(tag.encode())
                              + rb">([^\r\n<]+)", raw))
    require(len(matches) == 1, f"Expected one original header field: {tag}")
    return matches[0].group(1).decode("ascii").strip(), matches[0].start(1)


def calendar_window(accepted: datetime, session_dates: list[date], opens: dict):
    # Deliberately enumerate eligible dates instead of using searchsorted,
    # previous_session, session_offset, or the project's event_window helper.
    local_day = accepted.astimezone(NY).date()
    eligible = [day for day in session_dates if day > local_day]
    require(len(eligible) >= 22, "Insufficient development calendar dates")
    reference = eligible[1]
    controls = max(day for day in session_dates if day < reference)
    label_dates = [day for day in session_dates if day > reference][:20]
    require(len(label_dates) == 20, "Incomplete 20-session label horizon")
    return {
        "acceptance_timestamp": accepted.isoformat(),
        "acceptance_timestamp_utc": accepted.astimezone(timezone.utc).isoformat(),
        "acceptance_date": local_day.isoformat(),
        "first_strict_after_session": eligible[0].isoformat(),
        "controls_through": controls.isoformat(),
        "reference_session": reference.isoformat(),
        "prediction_time_utc": opens[reference],
        "label_first": label_dates[0].isoformat(),
        "label_end": label_dates[-1].isoformat(),
        "label_sessions": [day.isoformat() for day in label_dates],
    }


def main(root: Path, output: Path):
    started = datetime.now(timezone.utc).isoformat()
    require(not output.exists(), "Preserve previous evidence; choose a new output file")
    captured = {}

    def capture(relative):
        raw = read(root / relative)
        captured[relative] = raw
        return raw

    packet_raw = capture("reports/filing_review/packet.json")
    packet = parse(packet_raw)
    receipt = parse(capture("reports/filing_review/receipt.json"))
    expected_packet = next(row for row in receipt["files"] if row["file"] == "packet.json")
    require(binding(packet_raw) == {key: expected_packet[key] for key in ("sha256", "bytes")},
            "Packet differs from published receipt")
    canonical_packet = json.dumps({key: value for key, value in packet.items() if key != "packet_id"},
                                  sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                                  allow_nan=False).encode()
    require(digest(canonical_packet) == packet["packet_id"] == receipt["packet_id"],
            "Packet fingerprint differs")
    require(packet["market_returns_read"] is False and packet["final_period_opened"] is False,
            "Packet scope is not public SEC development evidence")
    protocol = parse(capture("configs/protocol.json"))
    protocol_digest = digest(json.dumps(protocol, sort_keys=True, separators=(",", ":"),
                                        ensure_ascii=True).encode())
    require(protocol_digest == packet["protocol_sha256"], "Protocol fingerprint differs")
    require(protocol["reference_session_offset"] == 2 and protocol["horizon_sessions"] == 20
            and protocol["calendar"] == "XNYS" and protocol["timezone"] == "America/New_York"
            and protocol["initial_train_start"] == 2010 and protocol["development_end"] == 2021,
            "Frozen timing specification differs")
    blobs = {}
    for role, relative in SOURCE_FILES.items():
        raw = capture(relative)
        bound = packet["source_bindings"][role]
        require(binding(raw) == {key: bound[key] for key in ("sha256", "bytes")},
                f"Packet source binding differs: {role}")
        blobs[role] = raw
    audit = parse(blobs["audit_summary"])
    require(audit["market_returns_used"] is False, "Original audit consumed market returns")
    for role, field in (("filings", "source_table_sha256"), ("pairs", "pair_table_sha256"),
                        ("evidence", "evidence_table_sha256")):
        require(digest(blobs[role]) == audit[field], f"Original audit binding differs: {role}")

    # All parquet date checks run before decoding any non-date columns.
    for role, columns in (("filings", ["acceptance_date", "acceptance_timestamp"]),
                          ("pairs", ["acceptance_date", "previous_acceptance_date"]),
                          ("evidence", ["acceptance_timestamp"])):
        date_rows = pq.ParquetFile(io.BytesIO(blobs[role])).read(columns=columns).to_pylist()
        for row in date_rows:
            for key, value in row.items():
                if "timestamp" in key:
                    development_day(aware(value).astimezone(NY).date().isoformat())
                else:
                    development_day(value)
    filing_columns = ["accessionNumber", "cik", "name", "form", "filingDate", "reportDate",
                      "acceptance_date", "acceptance_timestamp", "acceptanceDateTime",
                      "source_url", "header_url", "download_sha256", "header_sha256",
                      "risk_source_url", "risk_source_sha256", "resolution_index_url",
                      "resolution_index_sha256", "reference_session", "controls_through",
                      "label_end", "prediction_time_utc", "extraction_status", "acceptance_source"]
    filing_rows = pq.read_table(io.BytesIO(blobs["filings"]), columns=filing_columns).to_pylist()
    evidence_rows = pq.read_table(io.BytesIO(blobs["evidence"])).to_pylist()
    pair_columns = ["cik", "accession", "previous_accession", "acceptance_date",
                    "previous_acceptance_date", "source_url", "previous_source_url"]
    pair_rows = pq.read_table(io.BytesIO(blobs["pairs"]), columns=pair_columns).to_pylist()
    filings = {row["accessionNumber"]: row for row in filing_rows}
    evidence = {row["accession"]: row for row in evidence_rows}
    packet_filings = {row["accession"]: row for row in packet["filings"]}
    require(len(filing_rows) == len(filings) == len(evidence_rows) == len(evidence) == 155,
            "Preserved source cohort is not 155 unique filings")
    require(len(packet_filings) == len(packet["filings"]) == 73, "Packet is not 73 unique filings")
    require(set(filings) == set(evidence) and set(packet_filings) <= set(filings),
            "Source/evidence accession coverage differs")
    require(len(pair_rows) == 135 and len(packet["pairs"]) == 30, "Frozen pair counts differ")
    for row in evidence_rows:
        expected = digest(json.dumps({key: row[key] for key in FINGERPRINT_FIELDS},
                                     sort_keys=True).encode())
        require(expected == row["evidence_id"], f"Evidence fingerprint differs: {row['accession']}")

    calendar = exchange_calendars.get_calendar("XNYS", start="2009-01-01", end="2021-12-31")
    schedule = calendar.schedule
    session_dates = [stamp.date() for stamp in schedule.index]
    opens = {stamp.date(): row["open"].isoformat() for stamp, row in schedule.iterrows()}
    require(len(session_dates) == len(set(session_dates)) and session_dates == sorted(session_dates),
            "Calendar session dates are not unique and increasing")
    calendar_rows = [{"session": day.isoformat(), "open_utc": opens[day]} for day in session_dates]
    calendar_sha256 = digest(json.dumps(calendar_rows, sort_keys=True, separators=(",", ":")).encode())
    source_bindings, checks = {}, []
    for accession, packet_row in packet_filings.items():
        item = {"accession": accession, "evidence_id": packet_row["evidence_id"],
                "reviewer_type": "assistant", "issues": [], "descriptive_observations": []}
        try:
            row, filing = evidence[accession], filings[accession]
            require(row["evidence_id"] == packet_row["evidence_id"], "Packet evidence is stale")
            for key in ("cik", "source_url", "header_url", "risk_source_url"):
                require(packet_row[key] == row[key] == filing[key], f"Source identity differs: {key}")
            for url_field, hash_field in (("source_url", "download_sha256"),
                                          ("header_url", "header_sha256"),
                                          ("risk_source_url", "risk_source_sha256")):
                require(row[hash_field] == filing[hash_field], f"Source hash differs: {hash_field}")
                body = cache_read(root, row[url_field], row[hash_field], source_bindings)
                if url_field == "header_url":
                    header = body
            if row["resolution_index_url"]:
                cache_read(root, row["resolution_index_url"], row["resolution_index_sha256"], source_bindings)
            value, offset = header_field(header, "ACCEPTANCE-DATETIME")
            require(re.fullmatch(r"\d{14}", value) is not None, "Noncanonical SGML acceptance value")
            wall = datetime.strptime(value, "%Y%m%d%H%M%S")
            accepted = wall.replace(tzinfo=NY)
            require(accepted.utcoffset() == wall.replace(tzinfo=NY, fold=1).utcoffset(),
                    "Ambiguous New York wall clock")
            require(accepted.astimezone(timezone.utc).astimezone(NY).replace(tzinfo=None) == wall,
                    "Nonexistent New York wall clock")
            development_day(accepted.date().isoformat())
            accession_value, _ = header_field(header, "ACCESSION-NUMBER")
            period_value, _ = header_field(header, "PERIOD")
            form_value, _ = header_field(header, "TYPE")
            filing_date_value, _ = header_field(header, "FILING-DATE")
            require(accession_value == accession, "Header accession differs")
            require(form_value == filing["form"] == "10-K", "Header is not the selected original 10-K")
            report_date = datetime.strptime(period_value, "%Y%m%d").date().isoformat()
            require(report_date == filing["reportDate"] == row["report_date"] == packet_row["report_date"],
                    "Header report period differs")
            filing_date = datetime.strptime(filing_date_value, "%Y%m%d").date().isoformat()
            require(filing_date == filing["filingDate"] == row["filing_date"], "Header filing date differs")
            company_blocks = re.findall(rb"(?is)<COMPANY-DATA>(.*?)</COMPANY-DATA>", header)
            header_companies = []
            for block in company_blocks:
                ciks = re.findall(rb"(?im)^\s*<CIK>\s*(\d+)\s*$", block)
                names = re.findall(rb"(?im)^\s*<CONFORMED-NAME>([^\r\n<]+)", block)
                require(len(ciks) == len(names) == 1, "Ambiguous original header company block")
                header_companies.append({"cik": ciks[0].decode().zfill(10),
                                         "name": names[0].decode("utf-8", errors="replace").strip()})
            matching = [company for company in header_companies if company["cik"] == row["cik"]]
            require(len(matching) == 1, "Selected issuer CIK does not uniquely match original header")
            expected = calendar_window(accepted, session_dates, opens)
            for key in ("acceptance_timestamp", "reference_session", "controls_through", "label_end"):
                require(expected[key] == row[key] == filing[key] == packet_row[key],
                        f"Independent SGML/session value differs: {key}")
            require(expected["acceptance_date"] == packet_row["acceptance_date"] == filing["acceptance_date"],
                    "New York acceptance date differs")
            require(aware(expected["prediction_time_utc"]) == aware(filing["prediction_time_utc"]),
                    "Reference session open differs")
            require(filing["acceptance_source"] == "sgml_header", "Stored clock source is not SGML header")
            api = aware(row["api_timestamp"])
            require(row["api_timestamp"] == packet_row["api_timestamp"] == filing["acceptanceDateTime"],
                    "API timestamp differs between inputs")
            delta = int((api - accepted).total_seconds())
            require(delta == row["api_header_difference_seconds"], "Stored API/header difference differs")
            if delta:
                item["descriptive_observations"].append("api_header_clock_difference_no_cause_assigned")
            if matching[0]["name"] != packet_row["name"]:
                item["descriptive_observations"].append("original_header_name_differs_from_packet_display_name")
            item.update(independent_clock=expected, original_acceptance_value=value,
                        original_acceptance_byte_offset=offset,
                        original_header_url=row["header_url"], original_header_sha256=row["header_sha256"],
                        original_filing_date=filing_date, original_report_date=report_date,
                        original_header_companies=header_companies,
                        selected_original_header_company=matching[0], packet_display_name=packet_row["name"],
                        api_timestamp=row["api_timestamp"], api_minus_header_seconds=delta,
                        ny_utc_offset_seconds=int(accepted.utcoffset().total_seconds()),
                        api_difference_equals_negative_ny_utc_offset=(delta == -accepted.utcoffset().total_seconds()),
                        source_urls=[row[key] for key in ("source_url", "header_url", "risk_source_url")])
        except (ValueError, KeyError, OSError) as error:
            item["issues"].append(str(error))
        item["timing_source_check_pass"] = not item["issues"]
        item["public_dissemination_verified"] = False
        item["historical_security_identity_approved"] = False
        checks.append(item)

    groups = defaultdict(list)
    for row in filing_rows:
        groups[row["cik"]].append(row)
    for group in groups.values():
        group.sort(key=lambda row: (date.fromisoformat(row["acceptance_date"]), row["accessionNumber"]))
    pair_index = {(row["accession"], row["previous_accession"]): row for row in pair_rows}
    require(len(pair_index) == len(pair_rows), "Duplicate stored pair keys")
    selected_checks = []
    for selected in packet["pairs"]:
        case = {**selected, "issues": [], "broader_population_completeness_established": False}
        try:
            current, previous = filings[selected["accession"]], filings[selected["previous_accession"]]
            require(selected["cik"] == current["cik"] == previous["cik"], "Pair issuer CIK differs")
            require(selected["acceptance_date"] == current["acceptance_date"], "Pair acceptance date differs")
            group = groups[selected["cik"]]
            idx = next(i for i, row in enumerate(group) if row["accessionNumber"] == selected["accession"])
            require(idx > 0 and group[idx - 1]["accessionNumber"] == selected["previous_accession"],
                    "Selected prior filing is not adjacent within the preserved 155-source cohort")
            require(aware(previous["acceptance_timestamp"]) < aware(current["acceptance_timestamp"]),
                    "Original acceptance timestamps are not increasing")
            prior_report, current_report = map(date.fromisoformat, (previous["reportDate"], current["reportDate"]))
            gap = (current_report - prior_report).days
            require(300 <= gap <= 430, "Report periods are not an allowed increasing annual pair")
            require(current["form"] == previous["form"] == "10-K" and
                    current["extraction_status"] == previous["extraction_status"] == "ok",
                    "Pair does not retain two eligible original filings")
            stored_pair = pair_index[(selected["accession"], selected["previous_accession"])]
            for key, expected in (("cik", selected["cik"]), ("source_url", current["source_url"]),
                                  ("previous_source_url", previous["source_url"]),
                                  ("acceptance_date", current["acceptance_date"]),
                                  ("previous_acceptance_date", previous["acceptance_date"])):
                require(stored_pair[key] == expected, f"Stored pair field differs: {key}")
            case.update(previous_report_date=prior_report.isoformat(), current_report_date=current_report.isoformat(),
                        report_gap_days=gap, previous_acceptance_timestamp=previous["acceptance_timestamp"],
                        current_acceptance_timestamp=current["acceptance_timestamp"],
                        cohort_issuer_filings=len(group), current_cohort_position=idx + 1,
                        predecessor_adjacency_within_preserved_cohort=True)
        except (ValueError, KeyError, StopIteration) as error:
            case["issues"].append(str(error))
        case["pair_check_pass"] = not case["issues"]
        selected_checks.append(case)

    prior_raw = capture("reports/review_progress/assistant_filing_decisions.jsonl")
    prior_receipt = parse(capture("reports/review_progress/source_review_receipt.json"))
    old_bindings = prior_receipt["bindings"]
    for field, role in (("original_audit_receipt", "audit_summary"),
                        ("original_filing_evidence", "evidence"), ("filing_table", "filings"),
                        ("pair_table", "pairs"), ("fixed_pair_selection", "selected_pairs")):
        require(old_bindings[field] == digest(blobs[role]), f"Prior receipt source binding differs: {field}")
    require(old_bindings["assistant_review_decisions"] == digest(prior_raw), "Prior decision file changed")
    prior_checks, seen = [], set()
    checked_at = datetime.now(timezone.utc)
    for line in prior_raw.splitlines():
        if not line.strip():
            continue
        original = parse(line)
        accession = original["accession"]
        case = {"accession": accession, "original_record": original,
                "original_line_sha256": digest(line), "issues": []}
        try:
            require(accession not in seen, "Duplicate prior accession")
            seen.add(accession)
            require(accession in packet_filings, "Prior accession outside fixed review packet")
            row = evidence[accession]
            require(original["evidence_id"] == row["evidence_id"] == packet_filings[accession]["evidence_id"],
                    "Prior decision evidence ID is stale")
            require(original["reviewer_type"] == "assistant" and original["reviewer"].strip(),
                    "Prior assistant authorship differs")
            require(aware(original["reviewed_at"]) <= checked_at, "Future prior review timestamp")
            require(original["boundary_verdict"] == original["timing_verdict"] == "pass"
                    and original["notes"].strip(), "Prior record does not declare the preserved completed scope")
            required_urls = {row["source_url"], row["header_url"], row["risk_source_url"]}
            require(set(original["source_references"]) >= required_urls, "Prior record lacks inspected source references")
        except (ValueError, KeyError) as error:
            case["issues"].append(str(error))
        case["prior_record_binding_pass"] = not case["issues"]
        case["original_author_and_timestamp_preserved"] = True
        prior_checks.append(case)
    require(len(prior_checks) == 63, "Prior review count differs from 63")

    for relative, raw in captured.items():
        require(read(root / relative) == raw, f"Input changed during investigation: {relative}")
    for entry in source_bindings.values():
        cache_path = root / "data/raw/sec_cache" / entry["cache_key"]
        require(digest(read(cache_path.with_suffix(".bin"))) == entry["sha256"] and
                digest(read(cache_path.with_suffix(".json"))) == entry["metadata_sha256"],
                "Original SEC cache changed during investigation")
    errors = sum(len(row["issues"]) for row in checks + selected_checks + prior_checks)
    result = {
        "schema_version": 1,
        "status": "INDEPENDENT_TIMING_AND_PRIOR_BINDINGS_VERIFIED" if errors == 0 else "CASE_ISSUES_RECORDED",
        "started_at_utc": started, "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "performed_by": "ChatGPT research assistant / timing_prior", "reviewer_type": "assistant",
        "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
        "script_sha256": digest(Path(__file__).read_bytes()), "packet_id": packet["packet_id"],
        "bindings": {relative: binding(raw) for relative, raw in captured.items()},
        "method": {
            "sgml_clock": "Unique original ACCEPTANCE-DATETIME digits; explicit America/New_York zone; reject ambiguous/nonexistent wall time.",
            "session_arithmetic": "Enumerate XNYS schedule dates strictly after New York acceptance date; second date is reference; preceding session is controls-through; first 20 strictly after reference are label dates.",
            "shared_calendar_dependency": "exchange_calendars; independent arithmetic is not an independent external calendar source.",
            "project_timing_or_audit_helpers_called": False,
            "packet_and_source_hashes_rechecked_at_finish": True,
            "api_difference_cause_assigned": False,
            "pairing_scope": "Predecessor adjacency within the preserved 155-source cohort only.",
        },
        "runtime": {"exchange_calendars": importlib.metadata.version("exchange_calendars"),
                    "tzdata": importlib.metadata.version("tzdata"),
                    "pyarrow": importlib.metadata.version("pyarrow")},
        "calendar": {"name": "XNYS", "start": "2009-01-01", "end": "2021-12-31",
                     "session_count": len(calendar_rows), "session_and_open_rows_sha256": calendar_sha256},
        "summary": {
            "packet_filings": len(checks), "timing_source_passes": sum(row["timing_source_check_pass"] for row in checks),
            "selected_pairs": len(selected_checks), "pair_passes": sum(row["pair_check_pass"] for row in selected_checks),
            "preserved_source_cohort": len(filing_rows), "unique_original_sec_sources_rehashed": len(source_bindings),
            "prior_records": len(prior_checks), "prior_bindings_pass": sum(row["prior_record_binding_pass"] for row in prior_checks),
            "additional_packet_filings_without_prior_decision": sorted(set(packet_filings) - seen),
            "api_minus_header_seconds_counts": dict(sorted(Counter(str(row["api_minus_header_seconds"]) for row in checks
                                                                        if "api_minus_header_seconds" in row).items())),
            "original_display_name_differences": sum("original_header_name_differs_from_packet_display_name" in row["descriptive_observations"] for row in checks),
            "issues": errors,
        },
        "filing_checks": checks, "pair_checks": selected_checks,
        "preserved_prior_record_checks": prior_checks,
        "original_sec_cache_bindings": sorted(source_bindings.values(), key=lambda row: row["url"]),
        "market_returns_read": False, "human_reviews_created": 0, "source_approvals": 0,
        "historical_security_links_created": 0, "original_reviews_modified": False,
        "prior_arithmetic_review_modified": False, "public_dissemination_verified": False,
        "full_universe_representativeness_established": False,
        "model_ready": False, "final_period_opened": False,
    }
    with output.open("x") as handle:
        json.dump(result, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write("\n")
    print(json.dumps({"status": result["status"], "summary": result["summary"],
                      "output": str(output), "sha256": digest(output.read_bytes())}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    main(args.root.resolve(), args.output.resolve())
