"""Reproduce a source-DOM inventory for five specifically assigned JNJ filings.

This deliberately does not call the research extraction/normalization helper.
Explicit inspected DOM boundaries are selected, then all intervening siblings
are retained. It creates evidence inventory, never a reviewer verdict.
"""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

from lxml import html
import pyarrow.parquet as pq


ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
SPEC = {
    "0000200406-17-000006": ("/html/body/document/type/sequence/filename/description/text/table[31]", "/html/body/document/type/sequence/filename/description/text/table[37]"),
    "0000200406-18-000005": ("/html/body/document/type/sequence/filename/description/text/table[30]", "/html/body/document/type/sequence/filename/description/text/table[36]"),
    "0000200406-19-000009": ("/html/body/document/type/sequence/filename/description/text/table[34]", "/html/body/document/type/sequence/filename/description/text/table[40]"),
    "0000200406-20-000010": ("/html/body/div/table[33]", "/html/body/div/table[39]"),
    "0000200406-21-000008": ("/html/body/div[209]", "/html/body/div[335]"),
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def compact(text):
    return re.sub(r"\s+", "", text.replace("\u200b", ""))


def cache(url, expected):
    raw_path = ROOT / "data/raw/sec_cache" / (sha(url.encode()) + ".bin")
    raw = raw_path.read_bytes()
    metadata = json.loads(raw_path.with_suffix(".json").read_text())
    assert sha(raw) == expected == metadata["sha256"]
    assert len(raw) == metadata["bytes"]
    assert metadata["url"] == url
    assert metadata["status"] == 200
    return raw, {"url": url, "sha256": sha(raw), "bytes": len(raw), "metadata": metadata,
                 "cache_file": str(raw_path.relative_to(ROOT))}


def main():
    packet = json.loads((ROOT / "reports/filing_review/packet.json").read_text())
    cases = {f["accession"]: f for f in packet["filings"] if f["accession"] in SPEC}
    evidence = {f["accession"]: f for f in pq.read_table(ROOT / "outputs/audit-pilot-resolved/filing_evidence.parquet").to_pylist() if f["accession"] in SPEC}
    filings = {f["accessionNumber"]: f for f in pq.read_table(ROOT / "data/processed/pilot-resolved/filings.parquet").to_pylist() if f["accessionNumber"] in SPEC}
    results = []
    for accession, (start_path, end_path) in SPEC.items():
        case, ev, filing = cases[accession], evidence[accession], filings[accession]
        assert case["risk_source_url"] == case["source_url"] == ev["source_url"] == filing["source_url"]
        assert case["evidence_id"] == ev["evidence_id"]
        assert case["risk_text"] == filing["risk_text"]
        assert sha(case["risk_text"].encode()) == ev["risk_text_sha256"]
        raw, source_binding = cache(case["source_url"], ev["download_sha256"])
        header, header_binding = cache(case["header_url"], ev["header_sha256"])
        tree = html.fromstring(raw)
        start, = tree.xpath(start_path)
        end, = tree.xpath(end_path)
        assert start.getparent() is end.getparent()
        assert re.fullmatch(r"Item\s*1A\.?RISKFACTORS", compact(start.text_content()), re.I)
        assert "UNRESOLVEDSTAFFCOMMENTS" in compact(end.text_content()).upper()
        nodes = []
        sibling = start.getnext()
        while sibling is not end:
            assert sibling is not None
            if isinstance(sibling.tag, str):
                node_text = sibling.text_content()
                if node_text.strip():
                    nodes.append({"number": len(nodes) + 1, "path": tree.getroottree().getpath(sibling),
                                  "tag": sibling.tag, "text": node_text,
                                  "links": [{"text": a.text_content(), "href": a.get("href")} for a in sibling.xpath(".//a[@href]")]})
            sibling = sibling.getnext()
        full_span = "\n".join(n["text"] for n in nodes)
        same = compact(full_span) == compact(case["risk_text"])
        assert same, f"Independent character stream mismatch: {accession}"
        hidden = []
        nontext_elements = []
        for node in start.itersiblings():
            if node is end:
                break
            for child in node.iter():
                if not isinstance(child.tag, str):
                    continue
                style = re.sub(r"\s+", "", child.get("style", "").lower())
                if "display:none" in style or "visibility:hidden" in style or child.tag.lower() in {"script", "style", "ix:hidden"}:
                    hidden.append({"path": tree.getroottree().getpath(child), "tag": child.tag,
                                   "text": child.text_content()[:300]})
                if child.tag.lower() in {"img", "svg", "math", "canvas", "iframe", "object", "embed"}:
                    nontext_elements.append({"path": tree.getroottree().getpath(child), "tag": child.tag,
                                             "alt": child.get("alt"), "src": child.get("src")})
        risk_mentions = []
        for n in tree.xpath("//*[not(*)]"):
            if not isinstance(n.tag, str):
                continue
            text = n.text_content()
            if "risk factors" in " ".join(text.lower().split()) and len(text) < 1000:
                risk_mentions.append({"path": tree.getroottree().getpath(n), "text": text,
                                      "href": n.get("href")})
        record = {
            "accession": accession, "evidence_id": case["evidence_id"], "source": source_binding,
            "header": header_binding, "header_text": header.decode(),
            "risk_text_sha256": ev["risk_text_sha256"], "risk_text_chars": len(case["risk_text"]),
            "independent_dom_start_path": start_path, "independent_dom_end_path": end_path,
            "source_start_heading": start.text_content(), "source_end_heading": end.text_content(),
            "preceding_source_node": start.getprevious().text_content(),
            "following_source_node": end.getnext().text_content(),
            "nonempty_direct_sibling_nodes": len(nodes), "all_nonwhitespace_characters_equal": same,
            "comparison_omits_only_whitespace_and_zero_width_space": True,
            "hidden_or_script_nodes_in_risk_span": hidden,
            "nontext_elements_in_risk_span": nontext_elements,
            "risk_factor_mentions_elsewhere_and_heading": risk_mentions,
            "nodes": nodes,
            "source_inspected_by_script_at": datetime.now(timezone.utc).isoformat(),
            "review_verdict_created": False,
        }
        (OUT / f"{accession}.source_inventory.json").write_text(json.dumps(record, indent=2, ensure_ascii=False) + "\n")
        (OUT / f"{accession}.source_reading.txt").write_text("\n\n".join(f"[{n['number']:03d}] {n['path']}\n{n['text']}" for n in nodes) + "\n")
        results.append({"accession": accession, "nodes": len(nodes), "full_span_chars": len(full_span),
                        "risk_chars": len(case["risk_text"]), "all_nonwhitespace_characters_equal": same,
                        "hidden_node_count": len(hidden)})
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
